//
//  AppDelegate.h
//  SignalRText
//
//  Created by Mr.Sun on 2018/3/23.
//  Copyright © 2018年 SunXZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

