//
//  ViewController.m
//  SignalRText
//
//  Created by Mr.Sun on 2018/3/23.
//  Copyright © 2018年 SunXZ. All rights reserved.
//

#import "ViewController.h"
#import "SignalR.h"
@interface ViewController ()<UITextViewDelegate>

@property (nonatomic,strong) UIButton *button;
@property (nonatomic, strong) UILabel *IDlabel;
@property (nonatomic, strong) UITextField *inputText1;
@property (nonatomic, strong) SRHubProxy *chat;

@property (nonatomic, strong) NSString *contentStr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor cyanColor];
//    self.view.backgroundColor = [UIColor redColor];
//
//
    self.IDlabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 100, 200, 40)];
    _IDlabel.backgroundColor = [UIColor whiteColor];
    _IDlabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_IDlabel];
    
    
    
    self.contentStr = [NSString new];
    
    self.inputText1 = [[UITextField alloc] initWithFrame:CGRectMake(30, 160, 200, 40)];
    
    _inputText1.placeholder = @"";
    
    
    
    _inputText1.backgroundColor = [UIColor yellowColor];
    _inputText1.minimumFontSize= 1;
    _inputText1.enabled = YES;
    _inputText1.borderStyle = UITextBorderStyleNone;
    
    self.contentStr = _inputText1.text;
    [self.view addSubview:_inputText1];
  
    
    self.button = [UIButton buttonWithType:UIButtonTypeSystem];
    _button.frame = CGRectMake(240, 160, 40, 40);
    _button.backgroundColor = [UIColor redColor];
    [_button setTitle:@"发送" forState:UIControlStateNormal];
    
    
    [_button addTarget:self action:@selector(LogButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view addSubview:_button];
    
    
    
    //接收信息
    
    
    SRHubConnection *hubConnection = [SRHubConnection connectionWithURLString:@"http://test.nixinyi.com/"];
    
    
   self.chat = [hubConnection createHubProxy:@"ChatHub"];
    
    [_chat on:@"Chat" perform:self selector:@selector(addMessage:)];
    
    
   
    
    //开始
    [hubConnection start];
    
    
    
#pragma mark-----------连接使用
    //连接开始
    [hubConnection setStarted:^{
        NSLog(@"连接开始");
        
    }];
    //接收到的数据
    [hubConnection setReceived:^(NSString *message) {
        NSLog(@"接收到的数据:%@", message);

        _IDlabel.text = message;

    }];

    //连接缓慢
    [hubConnection setConnectionSlow:^{
        NSLog(@"连接缓慢");

    }];

    //重新连接
    [hubConnection setReconnecting:^{
        NSLog(@"重新连接");
    }];

    //重新连接2
    [hubConnection setReconnected:^{

        NSLog(@"重新连接2");
    }];

    //关闭连接
    [hubConnection setClosed:^{
        NSLog(@"关闭连接");
    }];
    //连接错误
    [hubConnection setError:^(NSError *error) {

        NSLog(@"error%@", error);
    }];

    //认可连接
    [hubConnection setReceived:^(NSString *data) {

        NSLog(@"认可连接");

    }];



    
}

/*
[NSCharacterSet alphanumericCharacterSet];          //所有数字和字母(大小写)
[NSCharacterSet decimalDigitCharacterSet];          //0-9的数字
[NSCharacterSet letterCharacterSet];                //所有字母
[NSCharacterSet lowercaseLetterCharacterSet];       //小写字母
[NSCharacterSet uppercaseLetterCharacterSet];       //大写字母
[NSCharacterSet punctuationCharacterSet];           //标点符号
[NSCharacterSet whitespaceAndNewlineCharacterSet];  //空格和换行符
[NSCharacterSet whitespaceCharacterSet];            //空格

*/
-(void)addMessage:(NSString *)Chat{
    //去除括号
    Chat = [Chat stringByTrimmingCharactersInSet:[NSCharacterSet punctuationCharacterSet]];//content":"的人
    //删除指定范围内字符
    NSString *endStr = [(NSMutableString *)Chat stringByReplacingCharactersInRange:NSMakeRange(0, 10) withString:@""];
    
    _IDlabel.text = endStr;
    
    NSLog(@"-----------%@---------------",endStr);
    NSLog(@"=========%@=================", Chat);
    
}



-(void)LogButton:(UIButton *)sender{
    //发送

    
    
    
//    [_chat invoke:@"Chat" withArgs:Arr];
    
    
    
    NSLog(@"我点了发送了" );

    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
